package com.careerinsta.insta_clone.repository;

import com.careerinsta.insta_clone.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByUserName(String username); // Query by username
}

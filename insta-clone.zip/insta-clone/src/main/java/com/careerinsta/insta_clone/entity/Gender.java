package com.careerinsta.insta_clone.entity;

public enum Gender {
	
		Male,
		Female,
		Other
	

}

package com.careerinsta.insta_clone.service;

import com.careerinsta.insta_clone.entity.User;
import com.careerinsta.insta_clone.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NewUserServiceImpl implements NewUserService {

    private final UserRepository userRepository;

    @Autowired
    public NewUserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User findByUserName(String username) {
        return userRepository.findByUserName(username);
    }

    @Override
    public void registerUser(User user) {
        userRepository.save(user);
    }

    @Override
    public boolean passwordMatches(String rawPassword, String encodedPassword) {
        // Add your password encoding/decoding logic here
        return rawPassword.equals(encodedPassword);
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();  // Fetch all users from the database
    }
    public void updateUser(User user) {
        userRepository.save(user); // Assuming a JPA repository is being used
    }
    public void deleteUser(User user) {
        userRepository.delete(user); // Assuming a JPA repository is being used
    }

}

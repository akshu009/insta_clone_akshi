import org.springframework.web.bind.annotation.DeleteMapping;

@RestController
public class AuthController {

    private final NewUserService userService;

    @Autowired
    public AuthController(NewUserService userService) {
        this.userService = userService;
    }

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody User user) {
        if (userService.findByUserName(user.getUserName()) != null) {
            return ResponseEntity.badRequest().body("Username already taken.");
        }

        userService.registerUser(user);
        return ResponseEntity.ok("User registered successfully.");
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody User loginUser) {
        User user = userService.findByUserName(loginUser.getUserName());

        if (user != null && userService.passwordMatches(loginUser.getPasswordHash(), user.getPasswordHash())) {
            return ResponseEntity.ok("Login successful.");
        } else {
            return ResponseEntity.status(401).body("Invalid credentials.");
        }
    }

    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = userService.getAllUsers();
        if (users.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(users);
    }

    @GetMapping("/users/{username}")
    public ResponseEntity<User> findUserByUsername(@PathVariable String username) {
        User user = userService.findByUserName(username);
        if (user == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(user);
    }

    @PutMapping("/users/{username}")
    public ResponseEntity<String> updateUser(@PathVariable String username, @RequestBody User updatedUser) {
        User existingUser = userService.findByUserName(username);
        if (existingUser == null) {
            return ResponseEntity.notFound().build();
        }

        // Update user details
        existingUser.setEmail(updatedUser.getEmail());
        existingUser.setPasswordHash(updatedUser.getPasswordHash());
        userService.updateUser(existingUser);

        return ResponseEntity.ok("User updated successfully.");
    }

    @DeleteMapping("/users/{username}")
    public ResponseEntity<String> deleteUser(@PathVariable String username) {
        User existingUser = userService.findByUserName(username);
        if (existingUser == null) {
            return ResponseEntity.notFound().build();
        }

        userService.deleteUser(existingUser);
        return ResponseEntity.ok("User deleted successfully.");
    }
}
